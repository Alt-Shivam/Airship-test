==========================
Frequently Asked Questions
==========================

.. contents:: Table of Contents
    :depth: 3

What is a good starting point to develop understanding of Airship?
------------------------------------------------------------------
In the
`Learn Documentation <https://docs.airshipit.org/learn/index.html>`__

Where can I find more information about hardware infrastructure?
----------------------------------------------------------------
In the
`CNTT Documentation <https://github.com/cntt-n/CNTT/tree/master/doc/tech>`__
